@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.tsaesar.anatomy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private data class Structure(val ru: String, val latin: String, val group: String)

private val structures = listOf(
    Structure("Череп", "Cranium", "Скелет"),
    Structure("Позвоночник", "Columna vertebralis", "Скелет"),
    Structure("Грудина", "Sternum", "Скелет"),
    Structure("Ключица", "Clavicula", "Скелет"),
    Structure("Лопатка", "Scapula", "Скелет"),
    Structure("Плечевая кость", "Humerus", "Скелет"),
    Structure("Лучевая кость", "Radius", "Скелет"),
    Structure("Локтевая кость", "Ulna", "Скелет"),
    Structure("Тазовая кость", "Os coxae", "Скелет"),
    Structure("Бедренная кость", "Femur", "Скелет"),
    Structure("Большеберцовая кость", "Tibia", "Скелет"),
    Structure("Малоберцовая кость", "Fibula", "Скелет"),
    Structure("Большая грудная мышца", "Musculus pectoralis major", "Мышцы"),
    Structure("Дельтовидная мышца", "Musculus deltoideus", "Мышцы"),
    Structure("Двуглавая мышца плеча", "Musculus biceps brachii", "Мышцы"),
    Structure("Трёхглавая мышца плеча", "Musculus triceps brachii", "Мышцы"),
    Structure("Прямая мышца живота", "Musculus rectus abdominis", "Мышцы"),
    Structure("Большая ягодичная мышца", "Musculus gluteus maximus", "Мышцы"),
    Structure("Четырёхглавая мышца бедра", "Musculus quadriceps femoris", "Мышцы"),
    Structure("Икроножная мышца", "Musculus gastrocnemius", "Мышцы")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnatomyApp() }
    }
}

@Composable
private fun AnatomyApp() {
    var system by remember { mutableStateOf("Скелет") }
    var selected by remember { mutableStateOf(structures.first()) }
    var isolated by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val filtered = structures.filter { it.group == system &&
        (query.isBlank() || it.ru.contains(query, true) || it.latin.contains(query, true)) }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Anatomy RU 3D") }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = system == "Скелет", onClick = { system = "Скелет" }, label = { Text("Скелет") })
                    FilterChip(selected = system == "Мышцы", onClick = { system = "Мышцы" }, label = { Text("Мышцы") })
                }
                Spacer(Modifier.height(10.dp))
                Box(Modifier.fillMaxWidth().height(190.dp).background(Color(0xFFF3F5F7), RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (isolated) "Изолировано: ${selected.ru}" else "3D-сцена • $system", style = MaterialTheme.typography.headlineSmall)
                        Spacer(Modifier.height(8.dp))
                        Text("Вращение • масштаб • выбор структуры", color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск структуры") },
                    placeholder = { Text("Например: бедренная или Femur") }
                )
                Spacer(Modifier.height(8.dp))
                Text("Структуры: ${filtered.size}", style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(filtered) { item ->
                        ListItem(
                            modifier = Modifier.clickable { selected = item },
                            headlineContent = { Text(item.ru, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(item.latin, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { if (selected == item) Text("✓") }
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text("Выбрано: ${selected.ru}", style = MaterialTheme.typography.titleMedium)
                Text(selected.latin, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { isolated = !isolated }) { Text(if (isolated) "Показать всё" else "Изолировать") }
                    OutlinedButton(onClick = { isolated = false; query = "" }) { Text("Сбросить") }
                }
            }
        }
    }
}
