# Anatomy RU 3D — attribution

The anatomy data/model pipeline planned for this project uses material from **Z-Anatomy — The libre 3D atlas of anatomy**, licensed under **CC BY-SA 4.0**. Z-Anatomy incorporates material derived from **BodyParts3D — The Database Center for Life Science**, under its applicable CC BY-SA license.

Z-Anatomy attribution: Gauthier Kervyn, Marcin Zielinski, Lluis Vinent and contributors, Z-Anatomy Project.

This v0.6.0 build contains the 3D rendering/control prototype. It does **not** bundle the Z-Anatomy mesh assets yet; the real anatomical mesh will be added only after its exact source/provenance is verified.

License information: https://creativecommons.org/licenses/by-sa/4.0/
