@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.tsaesar.anatomy

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

private data class Structure(val ru: String, val latin: String, val group: String, val region: String)

private val structures = listOf(
    Structure("Череп","Cranium","Скелет","Голова"), Structure("Нижняя челюсть","Mandibula","Скелет","Голова"),
    Structure("Позвоночник","Columna vertebralis","Скелет","Туловище"), Structure("Грудина","Sternum","Скелет","Туловище"),
    Structure("Рёбра","Costae","Скелет","Туловище"), Structure("Ключица","Clavicula","Скелет","Плечевой пояс"),
    Structure("Лопатка","Scapula","Скелет","Плечевой пояс"), Structure("Плечевая кость","Humerus","Скелет","Верхняя конечность"),
    Structure("Лучевая кость","Radius","Скелет","Предплечье"), Structure("Локтевая кость","Ulna","Скелет","Предплечье"),
    Structure("Тазовая кость","Os coxae","Скелет","Таз"), Structure("Крестец","Os sacrum","Скелет","Таз"),
    Structure("Бедренная кость","Femur","Скелет","Нижняя конечность"), Structure("Надколенник","Patella","Скелет","Нижняя конечность"),
    Structure("Большеберцовая кость","Tibia","Скелет","Голень"), Structure("Малоберцовая кость","Fibula","Скелет","Голень"),
    Structure("Большая грудная мышца","Musculus pectoralis major","Мышцы","Грудь"), Structure("Дельтовидная мышца","Musculus deltoideus","Мышцы","Плечо"),
    Structure("Двуглавая мышца плеча","Musculus biceps brachii","Мышцы","Плечо"), Structure("Трёхглавая мышца плеча","Musculus triceps brachii","Мышцы","Плечо"),
    Structure("Прямая мышца живота","Musculus rectus abdominis","Мышцы","Живот"), Structure("Наружная косая мышца живота","Musculus obliquus externus abdominis","Мышцы","Живот"),
    Structure("Большая ягодичная мышца","Musculus gluteus maximus","Мышцы","Ягодичная область"), Structure("Четырёхглавая мышца бедра","Musculus quadriceps femoris","Мышцы","Бедро"),
    Structure("Двуглавая мышца бедра","Musculus biceps femoris","Мышцы","Бедро"), Structure("Икроножная мышца","Musculus gastrocnemius","Мышцы","Голень")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AnatomyApp() } }
}

@Composable private fun AnatomyApp() {
    var system by remember { mutableStateOf("Скелет") }
    var selected by remember { mutableStateOf(structures.first()) }
    var isolated by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("Все") }
    val availableRegions = listOf("Все") + structures.filter { it.group == system }.map { it.region }.distinct()
    val filtered = structures.filter { it.group == system && (region == "Все" || it.region == region) &&
        (query.isBlank() || it.ru.contains(query,true) || it.latin.contains(query,true) || it.region.contains(query,true)) }
    LaunchedEffect(system) { region="Все"; selected=structures.first { it.group==system }; isolated=false }
    MaterialTheme {
        Scaffold(topBar={ TopAppBar(title={Text("Anatomy RU 3D")}) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(10.dp)) {
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected=system=="Скелет",onClick={system="Скелет"},label={Text("Скелет")})
                    FilterChip(selected=system=="Мышцы",onClick={system="Мышцы"},label={Text("Мышцы")})
                }
                Spacer(Modifier.height(6.dp))
                AndroidView(
                    factory={ ctx -> AnatomyGLView(ctx).apply { setSelection(selected.ru, isolated) } },
                    update={ it.setSelection(selected.ru, isolated) },
                    modifier=Modifier.fillMaxWidth().height(235.dp).then(Modifier)
                )
                Spacer(Modifier.height(6.dp))
                Text("3D-сцена • двумя пальцами масштабируй, одним вращай", style=MaterialTheme.typography.labelMedium)
                OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth(),singleLine=true,
                    label={Text("Поиск структуры")},placeholder={Text("Русское или латинское название")})
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected=region=="Все",onClick={region="Все"},label={Text("Все области")})
                    if(region!="Все") FilterChip(selected=true,onClick={region="Все"},label={Text(region)})
                    else if(availableRegions.size>1) FilterChip(selected=false,onClick={region=availableRegions[1]},label={Text("Область")})
                }
                Text("Найдено: ${filtered.size}",style=MaterialTheme.typography.titleSmall)
                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(1.dp)) {
                    items(filtered) { item ->
                        ListItem(modifier=Modifier.clickable{selected=item;isolated=false},headlineContent={Text(item.ru,maxLines=1,overflow=TextOverflow.Ellipsis)},
                            supportingContent={Text("${item.latin} • ${item.region}",maxLines=1,overflow=TextOverflow.Ellipsis)},
                            trailingContent={if(selected==item)Text("✓")})
                    }
                }
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(8.dp)) {
                    Text(selected.ru,style=MaterialTheme.typography.titleMedium); Text(selected.latin,color=Color.Gray); Text("Область: ${selected.region}",color=Color.Gray)
                }}
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                    Button(onClick={isolated=!isolated}){Text(if(isolated)"Показать всё" else "Изолировать")}
                    OutlinedButton(onClick={isolated=false;query="";region="Все"}){Text("Сбросить")}
                }
            }
        }
    }
}

private class AnatomyGLView(context: Context): GLSurfaceView(context) {
    private val renderer = SkeletonRenderer()
    init { setEGLContextClientVersion(2); setRenderer(renderer); renderMode=RENDERMODE_CONTINUOUSLY }
    fun setSelection(name:String, isolated:Boolean){ renderer.selection=name; renderer.isolated=isolated }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN -> { renderer.lastX=e.x; renderer.lastY=e.y; return true }
            MotionEvent.ACTION_MOVE -> {
                val dx=e.x-renderer.lastX; val dy=e.y-renderer.lastY
                renderer.angleY += dx*0.45f; renderer.angleX += dy*0.45f
                renderer.lastX=e.x; renderer.lastY=e.y; return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> { renderer.lastDistance=distance(e); return true }
            MotionEvent.ACTION_MOVE -> if(e.pointerCount>=2) {
                val d=distance(e); if(renderer.lastDistance>0f) renderer.zoom *= (d/renderer.lastDistance).coerceIn(0.92f,1.08f)
                renderer.lastDistance=d; return true
            }
        }
        return true
    }
    private fun distance(e:MotionEvent):Float { if(e.pointerCount<2)return 0f; val dx=e.getX(0)-e.getX(1); val dy=e.getY(0)-e.getY(1); return kotlin.math.sqrt(dx*dx+dy*dy) }
}

private class SkeletonRenderer: GLSurfaceView.Renderer {
    var angleX=8f; var angleY=-12f; var zoom=1.05f; var lastX=0f; var lastY=0f; var lastDistance=0f
    var selection="Череп"; var isolated=false
    private lateinit var program:Program
    private val bones=mutableListOf<Bone>()
    override fun onSurfaceCreated(gl:GL10?,config:EGLConfig?){ GLES20.glClearColor(.965f,.97f,.98f,1f); program=Program(); buildModel() }
    override fun onDrawFrame(gl:GL10?){
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT); GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val aspect= if(lastW>0) lastW.toFloat()/lastH else 1f; program.use()
        bones.forEach { b ->
            if(isolated && !matches(b.name,selection)) return@forEach
            val c=if(matches(b.name,selection)) floatArrayOf(.12f,.45f,.95f,1f) else floatArrayOf(.35f,.38f,.42f,1f)
            drawBone(b,aspect,c)
        }
    }
    private var lastW=1; private var lastH=1
    private fun drawBone(b:Bone,aspect:Float,color:FloatArray){
        val pts=floatArrayOf(b.a[0],b.a[1],b.a[2],b.b[0],b.b[1],b.b[2])
        program.draw(pts,angleX,angleY,zoom,aspect,color)
    }
    private fun buildModel(){
        fun add(n:String,a:FloatArray,b:FloatArray){bones+=Bone(n,a,b)}
        // schematic human skeleton in 3D: head, spine/ribs, shoulder/arms, pelvis, legs
        add("Череп",floatArrayOf(0f,2.65f,0f),floatArrayOf(0f,2.25f,0f))
        add("Нижняя челюсть",floatArrayOf(-.28f,2.42f,0f),floatArrayOf(.28f,2.42f,0f))
        for(i in 0..5){ val y=1.95f+i*.11f; add("Позвоночник",floatArrayOf(0f,y,0f),floatArrayOf(0f,y+.1f,0f)) }
        for(i in 0..4){ val y=1.95f-i*.18f; add("Рёбра",floatArrayOf(0f,y,0f),floatArrayOf(-.62f,y-.03f,0f)); add("Рёбра",floatArrayOf(0f,y,0f),floatArrayOf(.62f,y-.03f,0f)) }
        add("Ключица",floatArrayOf(-.08f,2.02f,0f),floatArrayOf(-.7f,2.02f,0f)); add("Ключица",floatArrayOf(.08f,2.02f,0f),floatArrayOf(.7f,2.02f,0f))
        add("Плечевая кость",floatArrayOf(-.72f,2.0f,0f),floatArrayOf(-.8f,1.2f,0f)); add("Плечевая кость",floatArrayOf(.72f,2.0f,0f),floatArrayOf(.8f,1.2f,0f))
        add("Лучевая кость",floatArrayOf(-.8f,1.2f,0f),floatArrayOf(-.7f,.45f,0f)); add("Локтевая кость",floatArrayOf(-.82f,1.2f,.04f),floatArrayOf(-.73f,.45f,.04f))
        add("Лучевая кость",floatArrayOf(.8f,1.2f,0f),floatArrayOf(.7f,.45f,0f)); add("Локтевая кость",floatArrayOf(.82f,1.2f,.04f),floatArrayOf(.73f,.45f,.04f))
        add("Тазовая кость",floatArrayOf(-.45f,.75f,0f),floatArrayOf(0f,.55f,0f)); add("Тазовая кость",floatArrayOf(.45f,.75f,0f),floatArrayOf(0f,.55f,0f))
        add("Крестец",floatArrayOf(0f,.75f,0f),floatArrayOf(0f,.35f,0f))
        add("Бедренная кость",floatArrayOf(-.32f,.55f,0f),floatArrayOf(-.4f,-.35f,0f)); add("Бедренная кость",floatArrayOf(.32f,.55f,0f),floatArrayOf(.4f,-.35f,0f))
        add("Большеберцовая кость",floatArrayOf(-.4f,-.35f,0f),floatArrayOf(-.43f,-1.2f,0f)); add("Малоберцовая кость",floatArrayOf(-.48f,-.35f,.05f),floatArrayOf(-.52f,-1.2f,.05f))
        add("Большеберцовая кость",floatArrayOf(.4f,-.35f,0f),floatArrayOf(.43f,-1.2f,0f)); add("Малоберцовая кость",floatArrayOf(.48f,-.35f,.05f),floatArrayOf(.52f,-1.2f,.05f))
        add("Стопа",floatArrayOf(-.43f,-1.2f,0f),floatArrayOf(-.72f,-1.2f,.08f)); add("Стопа",floatArrayOf(.43f,-1.2f,0f),floatArrayOf(.72f,-1.2f,.08f))
    }
    private fun matches(n:String,s:String)=n==s
    override fun onSurfaceChanged(gl:GL10?,w:Int,h:Int){lastW=w;lastH=h;GLES20.glViewport(0,0,w,h)}
}
private data class Bone(val name:String,val a:FloatArray,val b:FloatArray)

private class Program {
    private val vsh="""attribute vec3 aPos; uniform mat4 uM; void main(){gl_Position=uM*vec4(aPos,1.0);gl_PointSize=8.0;}"""
    private val fsh="""precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}"""
    private var p=0; private var pos=0; private var mat=0; private var col=0
    init { p=GLES20.glCreateProgram(); val vs=compile(GLES20.GL_VERTEX_SHADER,vsh); val fs=compile(GLES20.GL_FRAGMENT_SHADER,fsh); GLES20.glAttachShader(p,vs);GLES20.glAttachShader(p,fs);GLES20.glLinkProgram(p);pos=GLES20.glGetAttribLocation(p,"aPos");mat=GLES20.glGetUniformLocation(p,"uM");col=GLES20.glGetUniformLocation(p,"uColor") }
    private fun compile(type:Int,s:String):Int{val x=GLES20.glCreateShader(type);GLES20.glShaderSource(x,s);GLES20.glCompileShader(x);return x}
    fun use(){GLES20.glUseProgram(p)}
    fun draw(v:FloatArray,ax:Float,ay:Float,zoom:Float,aspect:Float,color:FloatArray){
        val fb=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer();fb.put(v).position(0)
        GLES20.glEnableVertexAttribArray(pos);GLES20.glVertexAttribPointer(pos,3,GLES20.GL_FLOAT,false,0,fb)
        val rx=Math.toRadians(ax.toDouble()); val ry=Math.toRadians(ay.toDouble()); val cx=cos(rx).toFloat();val sx=sin(rx).toFloat();val cy=cos(ry).toFloat();val sy=sin(ry).toFloat()
        val s=.58f*zoom
        val m=floatArrayOf(
            cy*s, sx*sy*s, -cx*sy*s,0f, 0f,cx*s,sx*s,0f, sy*s,-sx*cy*s,cx*cy*s,0f, 0f,-.2f,0f,1f)
        GLES20.glUniformMatrix4fv(mat,1,false,m,0);GLES20.glUniform4fv(col,1,color,0);GLES20.glLineWidth(6f);GLES20.glDrawArrays(GLES20.GL_LINES,0,2);GLES20.glDisableVertexAttribArray(pos)
    }
}
