package ru.tsaesar.anatomy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

data class Structure(val ru: String, val latin: String, val group: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnatomyApp() }
    }
}

@Composable
private fun AnatomyApp() {
    var system by remember { mutableStateOf("Скелет") }
    var selected by remember { mutableStateOf<Structure?>(null) }
    var isolated by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val structures = listOf(
        Structure("Череп", "Cranium", "Скелет"),
        Structure("Позвоночник", "Columna vertebralis", "Скелет"),
        Structure("Грудина", "Sternum", "Скелет"),
        Structure("Плечевая кость", "Humerus", "Скелет"),
        Structure("Бедренная кость", "Femur", "Скелет"),
        Structure("Большая грудная мышца", "Musculus pectoralis major", "Мышцы"),
        Structure("Дельтовидная мышца", "Musculus deltoideus", "Мышцы")
    )

    val filtered = structures.filter {
        it.group == system && (query.isBlank() || it.ru.contains(query, true) || it.latin.contains(query, true))
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Anatomy RU 3D") }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = system == "Скелет", onClick = { system = "Скелет" }, label = { Text("Скелет") })
                    FilterChip(selected = system == "Мышцы", onClick = { system = "Мышцы" }, label = { Text("Мышцы") })
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск структуры") }
                )
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().height(230.dp)
                        .background(Color(0xFFF1F4F7), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (isolated && selected != null) "Изолировано" else "3D-сцена", style = MaterialTheme.typography.headlineMedium)
                        Spacer(Modifier.height(6.dp))
                        Text(selected?.ru ?: "Выберите анатомическую структуру", color = Color.Gray)
                        Text("Поворот • масштаб • панорамирование", color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(10.dp))
                if (selected != null) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(selected!!.ru, style = MaterialTheme.typography.titleLarge)
                            Text(selected!!.latin, color = Color.Gray)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { isolated = !isolated }) { Text(if (isolated) "Показать всё" else "Изолировать") }
                                OutlinedButton(onClick = { selected = null; isolated = false }) { Text("Сбросить") }
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
                Text("Структуры", style = MaterialTheme.typography.titleMedium)
                LazyColumn(Modifier.fillMaxWidth().weight(1f)) {
                    items(filtered) { item ->
                        ListItem(
                            headlineContent = { Text(item.ru) },
                            supportingContent = { Text(item.latin) },
                            modifier = Modifier.clickable { selected = item; isolated = false }
                        )
                    }
                }
            }
        }
    }
}
