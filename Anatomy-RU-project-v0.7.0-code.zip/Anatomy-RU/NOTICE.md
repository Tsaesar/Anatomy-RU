# Anatomy RU 3D — attribution

This project bundles a converted GLB model derived from **Z-Anatomy — The libre 3D atlas of anatomy**, licensed under **CC BY-SA 4.0**. Z-Anatomy incorporates material derived from **BodyParts3D — The Database Center for Life Science**, under its applicable license.

Z-Anatomy attribution: Gauthier Kervyn, Marcin Zielinski, Lluis Vinent and contributors, Z-Anatomy Project.

The Android 3D rendering layer uses **Google Filament**, licensed under Apache License 2.0.

License information: https://creativecommons.org/licenses/by-sa/4.0/
