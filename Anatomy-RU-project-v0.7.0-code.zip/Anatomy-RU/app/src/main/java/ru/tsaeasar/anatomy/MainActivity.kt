@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.tsaesar.anatomy

import android.content.Context
import android.os.Bundle
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.filament.utils.ModelViewer
import com.google.android.filament.utils.Utils
import java.nio.ByteBuffer

private data class Structure(val ru: String, val latin: String, val group: String, val region: String)

private val structures = listOf(
    Structure("Череп", "Cranium", "Скелет", "Голова"), Structure("Нижняя челюсть", "Mandibula", "Скелет", "Голова"),
    Structure("Позвоночник", "Columna vertebralis", "Скелет", "Туловище"), Structure("Грудина", "Sternum", "Скелет", "Туловище"),
    Structure("Рёбра", "Costae", "Скелет", "Туловище"), Structure("Ключица", "Clavicula", "Скелет", "Плечевой пояс"),
    Structure("Лопатка", "Scapula", "Скелет", "Плечевой пояс"), Structure("Плечевая кость", "Humerus", "Скелет", "Верхняя конечность"),
    Structure("Лучевая кость", "Radius", "Скелет", "Предплечье"), Structure("Локтевая кость", "Ulna", "Скелет", "Предплечье"),
    Structure("Тазовая кость", "Os coxae", "Скелет", "Таз"), Structure("Крестец", "Os sacrum", "Скелет", "Таз"),
    Structure("Бедренная кость", "Femur", "Скелет", "Нижняя конечность"), Structure("Надколенник", "Patella", "Скелет", "Нижняя конечность"),
    Structure("Большеберцовая кость", "Tibia", "Скелет", "Голень"), Structure("Малоберцовая кость", "Fibula", "Скелет", "Голень"),
    Structure("Большая грудная мышца", "Musculus pectoralis major", "Мышцы", "Грудь"), Structure("Дельтовидная мышца", "Musculus deltoideus", "Мышцы", "Плечо"),
    Structure("Двуглавая мышца плеча", "Musculus biceps brachii", "Мышцы", "Плечо"), Structure("Трёхглавая мышца плеча", "Musculus triceps brachii", "Мышцы", "Плечо"),
    Structure("Прямая мышца живота", "Musculus rectus abdominis", "Мышцы", "Живот"), Structure("Наружная косая мышца живота", "Musculus obliquus externus abdominis", "Мышцы", "Живот"),
    Structure("Большая ягодичная мышца", "Musculus gluteus maximus", "Мышцы", "Ягодичная область"), Structure("Четырёхглавая мышца бедра", "Musculus quadriceps femoris", "Мышцы", "Бедро"),
    Structure("Двуглавая мышца бедра", "Musculus biceps femoris", "Мышцы", "Бедро"), Structure("Икроножная мышца", "Musculus gastrocnemius", "Мышцы", "Голень")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnatomyApp() }
    }
}

@Composable
private fun AnatomyApp() {
    var system by remember { mutableStateOf("Скелет") }
    var selected by remember { mutableStateOf(structures.first()) }
    var isolated by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("Все") }
    var viewer by remember { mutableStateOf<AnatomyModelView?>(null) }

    val availableRegions = listOf("Все") + structures.filter { it.group == system }.map { it.region }.distinct()
    val filtered = structures.filter {
        it.group == system &&
            (region == "Все" || it.region == region) &&
            (query.isBlank() || it.ru.contains(query, true) || it.latin.contains(query, true) || it.region.contains(query, true))
    }

    LaunchedEffect(system) {
        region = "Все"
        selected = structures.first { it.group == system }
        isolated = false
    }

    LaunchedEffect(selected, isolated) {
        viewer?.setSelection(selected, isolated)
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Anatomy RU 3D") }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = system == "Скелет", onClick = { system = "Скелет" }, label = { Text("Скелет") })
                    FilterChip(selected = system == "Мышцы", onClick = { system = "Мышцы" }, label = { Text("Мышцы") })
                }
                Spacer(Modifier.height(6.dp))

                AndroidView(
                    factory = { ctx ->
                        AnatomyModelView(ctx).also {
                            viewer = it
                            it.setSelection(selected, isolated)
                        }
                    },
                    update = {
                        viewer = it
                        it.setSelection(selected, isolated)
                    },
                    modifier = Modifier.fillMaxWidth().height(250.dp)
                )

                Spacer(Modifier.height(6.dp))
                Text("3D-сцена • одним пальцем вращение, двумя пальцами масштаб", style = MaterialTheme.typography.labelMedium)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск структуры") },
                    placeholder = { Text("Русское или латинское название") }
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = region == "Все", onClick = { region = "Все" }, label = { Text("Все области") })
                    if (region != "Все") FilterChip(selected = true, onClick = { region = "Все" }, label = { Text(region) })
                    else if (availableRegions.size > 1) FilterChip(selected = false, onClick = { region = availableRegions[1] }, label = { Text("Область") })
                }
                Text("Найдено: ${filtered.size}", style = MaterialTheme.typography.titleSmall)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                    items(filtered) { item ->
                        ListItem(
                            modifier = Modifier.clickable { selected = item; isolated = false },
                            headlineContent = { Text(item.ru, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text("${item.latin} • ${item.region}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { if (selected == item) Text("✓") }
                        )
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text(selected.ru, style = MaterialTheme.typography.titleMedium)
                        Text(selected.latin, color = Color.Gray)
                        Text("Область: ${selected.region}", color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(5.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { isolated = !isolated }) { Text(if (isolated) "Показать всё" else "Изолировать") }
                    OutlinedButton(onClick = { isolated = false; query = ""; region = "Все" }) { Text("Сбросить") }
                }
            }
        }
    }
}

private class AnatomyModelView(context: Context) : SurfaceView(context) {
    companion object {
        private var filamentInitialized = false
        private fun initFilament() {
            if (!filamentInitialized) {
                Utils.init()
                filamentInitialized = true
            }
        }
    }

    private val modelViewer: ModelViewer
    private val choreographer = Choreographer.getInstance()
    private var framePosted = false
    private var modelBuffer: ByteBuffer? = null
    private var appliedSignature = ""

    init {
        initFilament()
        modelViewer = ModelViewer(this)
        setOnTouchListener { _, event ->
            modelViewer.onTouchEvent(event)
            true
        }
        loadModel()
        postFrame()
    }

    private fun loadModel() {
        Thread {
            try {
                val bytes = context.assets.open("SkeletalSystem100.glb").use { it.readBytes() }
                val buffer = ByteBuffer.wrap(bytes)
                modelBuffer = buffer
                post {
                    modelViewer.loadModelGlb(buffer)
                    modelViewer.transformToUnitCube()
                    appliedSignature = ""
                }
            } catch (_: Exception) {
                // The UI remains usable even if the model cannot be loaded.
            }
        }.start()
    }

    fun setSelection(structure: Structure, isolated: Boolean) {
        val signature = "${structure.latin}|$isolated"
        if (signature == appliedSignature) return
        appliedSignature = signature
        post { applyVisibility(structure, isolated) }
    }

    private fun applyVisibility(structure: Structure, isolated: Boolean) {
        val asset = modelViewer.asset ?: return
        val rcm = modelViewer.engine.renderableManager
        val target = structure.latin.lowercase()
        for (entity in asset.entities) {
            if (!rcm.hasComponent(entity)) continue
            val name = asset.getName(entity).lowercase()
            val matches = name == target || name.contains(target) ||
                (structure.ru == "Большеберцовая кость" && name.contains("tibia")) ||
                (structure.ru == "Малоберцовая кость" && name.contains("fibula")) ||
                (structure.ru == "Бедренная кость" && name.contains("femur")) ||
                (structure.ru == "Плечевая кость" && name.contains("humerus")) ||
                (structure.ru == "Лучевая кость" && name.contains("radius")) ||
                (structure.ru == "Локтевая кость" && name.contains("ulna")) ||
                (structure.ru == "Надколенник" && name.contains("patella")) ||
                (structure.ru == "Ключица" && name.contains("clavicle")) ||
                (structure.ru == "Лопатка" && name.contains("scapula")) ||
                (structure.ru == "Крестец" && name.contains("sacrum")) ||
                (structure.ru == "Череп" && (name.contains("cranium") || name.contains("skull")))
            val instance = rcm.getInstance(entity)
            rcm.setLayerMask(instance, 0x01, if (!isolated || matches) 0x01 else 0x00)
        }
    }

    private fun postFrame() {
        if (framePosted) return
        framePosted = true
        choreographer.postFrameCallback(frameCallback)
    }

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            framePosted = false
            modelViewer.render(frameTimeNanos)
            postFrame()
        }
    }

    override fun onDetachedFromWindow() {
        choreographer.removeFrameCallback(frameCallback)
        framePosted = false
        modelViewer.destroy()
        modelBuffer = null
        super.onDetachedFromWindow()
    }
}
