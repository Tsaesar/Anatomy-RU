@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package ru.tsaesar.anatomy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

private data class Structure(
    val ru: String,
    val latin: String,
    val group: String,
    val region: String
)

private val structures = listOf(
    Structure("Череп", "Cranium", "Скелет", "Голова"),
    Structure("Нижняя челюсть", "Mandibula", "Скелет", "Голова"),
    Structure("Позвоночник", "Columna vertebralis", "Скелет", "Туловище"),
    Structure("Грудина", "Sternum", "Скелет", "Туловище"),
    Structure("Рёбра", "Costae", "Скелет", "Туловище"),
    Structure("Ключица", "Clavicula", "Скелет", "Плечевой пояс"),
    Structure("Лопатка", "Scapula", "Скелет", "Плечевой пояс"),
    Structure("Плечевая кость", "Humerus", "Скелет", "Верхняя конечность"),
    Structure("Лучевая кость", "Radius", "Скелет", "Предплечье"),
    Structure("Локтевая кость", "Ulna", "Скелет", "Предплечье"),
    Structure("Тазовая кость", "Os coxae", "Скелет", "Таз"),
    Structure("Крестец", "Os sacrum", "Скелет", "Таз"),
    Structure("Бедренная кость", "Femur", "Скелет", "Нижняя конечность"),
    Structure("Надколенник", "Patella", "Скелет", "Нижняя конечность"),
    Structure("Большеберцовая кость", "Tibia", "Скелет", "Голень"),
    Structure("Малоберцовая кость", "Fibula", "Скелет", "Голень"),
    Structure("Большая грудная мышца", "Musculus pectoralis major", "Мышцы", "Грудь"),
    Structure("Дельтовидная мышца", "Musculus deltoideus", "Мышцы", "Плечо"),
    Structure("Двуглавая мышца плеча", "Musculus biceps brachii", "Мышцы", "Плечо"),
    Structure("Трёхглавая мышца плеча", "Musculus triceps brachii", "Мышцы", "Плечо"),
    Structure("Прямая мышца живота", "Musculus rectus abdominis", "Мышцы", "Живот"),
    Structure("Наружная косая мышца живота", "Musculus obliquus externus abdominis", "Мышцы", "Живот"),
    Structure("Большая ягодичная мышца", "Musculus gluteus maximus", "Мышцы", "Ягодичная область"),
    Structure("Четырёхглавая мышца бедра", "Musculus quadriceps femoris", "Мышцы", "Бедро"),
    Structure("Двуглавая мышца бедра", "Musculus biceps femoris", "Мышцы", "Бедро"),
    Structure("Икроножная мышца", "Musculus gastrocnemius", "Мышцы", "Голень")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnatomyApp() }
    }
}

@Composable
private fun AnatomyApp() {
    var system by remember { mutableStateOf("Скелет") }
    var selected by remember { mutableStateOf(structures.first()) }
    var isolated by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var region by remember { mutableStateOf("Все") }

    val availableRegions = listOf("Все") + structures.filter { it.group == system }.map { it.region }.distinct()
    val filtered = structures.filter {
        it.group == system &&
        (region == "Все" || it.region == region) &&
        (query.isBlank() || it.ru.contains(query, true) || it.latin.contains(query, true) || it.region.contains(query, true))
    }

    LaunchedEffect(system) {
        region = "Все"
        val first = structures.firstOrNull { it.group == system }
        if (first != null) selected = first
        isolated = false
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Anatomy RU 3D") }) }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad).padding(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = system == "Скелет", onClick = { system = "Скелет" }, label = { Text("Скелет") })
                    FilterChip(selected = system == "Мышцы", onClick = { system = "Мышцы" }, label = { Text("Мышцы") })
                }
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier.fillMaxWidth().height(175.dp)
                        .background(Color(0xFFF3F5F7), RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (isolated) "Изолировано: ${selected.ru}" else "3D-сцена • $system",
                            style = MaterialTheme.typography.headlineSmall,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("Вращение • масштаб • выбор структуры", color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Поиск структуры") },
                    placeholder = { Text("Русское или латинское название") }
                )
                Spacer(Modifier.height(6.dp))
                Text("Область", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = region == "Все", onClick = { region = "Все" }, label = { Text("Все") })
                    if (availableRegions.size > 1) {
                        FilterChip(selected = region != "Все", onClick = {
                            val next = availableRegions.getOrNull(1) ?: "Все"
                            region = if (region == "Все") next else "Все"
                        }, label = { Text(if (region == "Все") "Выбрать область" else region) })
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("Найдено: ${filtered.size}", style = MaterialTheme.typography.titleSmall)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    items(filtered) { item ->
                        ListItem(
                            modifier = Modifier.clickable { selected = item; isolated = false },
                            headlineContent = { Text(item.ru, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text("${item.latin} • ${item.region}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            trailingContent = { if (selected == item) Text("✓") }
                        )
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(10.dp)) {
                        Text(selected.ru, style = MaterialTheme.typography.titleMedium)
                        Text(selected.latin, color = Color.Gray)
                        Text("Область: ${selected.region}", color = Color.Gray)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { isolated = !isolated }) { Text(if (isolated) "Показать всё" else "Изолировать") }
                    OutlinedButton(onClick = { isolated = false; query = ""; region = "Все" }) { Text("Сбросить") }
                }
            }
        }
    }
}
